# LaTeX2HTML 2019 (Released January 1, 2019)
# Associate internals original text with physical files.


$key = q/fig:example/;
$ref_files{$key} = "$dir".q|user_guide.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:insert-template/;
$ref_files{$key} = "$dir".q|user_guide.html|; 
$noresave{$key} = "$nosave";

1;

