#!/bin/sh

# Usage: xsf2pwtk.sh XSF2-file
# Purpose: convert XSF2 file to PWTK file

if test $# -lt 1; then
    input=-
else
    input=$1
fi


cat $input | awk '
BEGIN {
  f=1.0;
  bohr=0.529177;
}
/PRIMVEC/ { 
  if ( $2 != "bohr" ) {
    f = 1.0 / bohr;  
  }

  print "CELL_PARAMETERS cubic {";
  getline; printf "   %12.6f %12.6f %12.6f\n", $1*f, $2*f, $3*f; 
  getline; printf "   %12.6f %12.6f %12.6f\n", $1*f, $2*f, $3*f; 
  getline; printf "   %12.6f %12.6f %12.6f\n", $1*f, $2*f, $3*f; 
  print "}"; print "";
}
/PRIMCOORD/ {
  if ( NF < 2 ) {
    unit="angstrom";
  } else {
    unit=$2;
  }
  print "ATOMIC_POSITIONS ", unit, " { ";
  getline;
  nat=$1;
  for (i=0; i<nat; i++) 
   {
     getline; print;
   }
   print "}"; print "";
   print "SYSTEM { nat =", nat, "}\n";
}
'
